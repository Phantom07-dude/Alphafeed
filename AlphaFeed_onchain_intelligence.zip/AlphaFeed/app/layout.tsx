import "./globals.css";
import type { Metadata } from "next";
export const metadata: Metadata = {
  title:"AlphaFeed — Crypto Intelligence",
  description:"A real-time crypto intelligence dashboard for markets, wallets, whales, narratives and news."
};
export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="en"><body>{children}</body></html>;
}