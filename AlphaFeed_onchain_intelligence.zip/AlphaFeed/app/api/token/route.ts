import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { tokenIntelligence } from '@/lib/providers';
import { guard } from '@/lib/security';

const schema = z.object({
  address: z.string().regex(/^0x[a-fA-F0-9]{40}$/),
  chainId: z.string().regex(/^\d+$/).optional(),
  chain: z.string().max(40).optional(),
  pairAddresses: z.array(z.string().regex(/^0x[a-fA-F0-9]{40}$/)).max(20).optional(),
  change24h: z.number().finite().nullable().optional(),
  volume24h: z.number().finite().nullable().optional(),
  liquidity: z.number().finite().nullable().optional(),
});

export async function GET(req: NextRequest) {
  const limited = guard(req, 'token-intelligence', 12);
  if (limited) return limited;
  const parsed = schema.safeParse({
    address: req.nextUrl.searchParams.get('address'),
    chainId: req.nextUrl.searchParams.get('chainId') || undefined,
    chain: req.nextUrl.searchParams.get('chain') || undefined,
    pairAddresses: req.nextUrl.searchParams.getAll('pair').filter(Boolean),
    change24h: req.nextUrl.searchParams.get('change24h') ? Number(req.nextUrl.searchParams.get('change24h')) : undefined,
    volume24h: req.nextUrl.searchParams.get('volume24h') ? Number(req.nextUrl.searchParams.get('volume24h')) : undefined,
    liquidity: req.nextUrl.searchParams.get('liquidity') ? Number(req.nextUrl.searchParams.get('liquidity')) : undefined,
  });
  if (!parsed.success) return NextResponse.json({ error: 'Invalid token address or chain.' }, { status: 400 });
  try {
    return NextResponse.json(await tokenIntelligence(parsed.data.address, parsed.data.chainId || parsed.data.chain,  parsed.data.pairAddresses, { change24h: parsed.data.change24h, volume24h: parsed.data.volume24h, liquidity: parsed.data.liquidity }));
  } catch {
    return NextResponse.json({ configured: true, warning: 'On-chain provider unavailable.' }, { status: 502 });
  }
}
