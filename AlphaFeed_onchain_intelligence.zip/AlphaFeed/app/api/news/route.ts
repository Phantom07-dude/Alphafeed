import {NextRequest,NextResponse} from 'next/server'; import {news} from '@/lib/providers'; import {guard} from '@/lib/security';
export async function GET(req:NextRequest){const limited=guard(req,'news',20);if(limited)return limited;try{return NextResponse.json(await news())}catch{return NextResponse.json({items:[],live:false,warning:'News unavailable.'},{status:502})}}
