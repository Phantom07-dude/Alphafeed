import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { aiInsight } from '@/lib/providers';
import { guard } from '@/lib/security';

const schema=z.object({token:z.object({
  id:z.string().max(200),symbol:z.string().max(30),name:z.string().max(200),chain:z.string().max(40),
  price:z.number().nullable(),change24h:z.number().nullable(),marketCap:z.number().nullable(),volume24h:z.number().nullable(),
  liquidity:z.number().nullable(),fdv:z.number().nullable(),source:z.string().max(200)
})});
export async function POST(req:NextRequest){
  const limited=guard(req,'ai',5); if(limited)return limited;
  try{const b=schema.parse(await req.json());return NextResponse.json(await aiInsight(b.token));}
  catch(e:any){return NextResponse.json({error:e?.message||'AI unavailable.'},{status:400});}
}
